const charContainer = document.getElementById("character-container");

fetch("https://rickandmortyapi.com/api/character")
  .then((response) => {
    return response.json();
  })
  .then((responseData) => {
    for(let i = 0; i < responseData.results.length; i++) {
      charContainer.innerHTML += `
      <div class='col-25'>
        <div class='char-card'>
          <div class='char-card-image'>
            <img src='${responseData.results[i].image}' />
          </div>
          <div class='char-card-title'>
          ${responseData.results[i].name}
          </div>
          <div class='char-card-status'>
          ${responseData.results[i].status}
          </div>
        </div> 
      </div>`
    }
  });
