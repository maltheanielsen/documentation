getContacts();

function getContacts(){
  fetch("https://modelin.webexam-mcdm.dk/api/contacts")
  .then((res) => {
    return res.json();
  })
  .then((resData) => {
    console.log(resData);
  })
}

function postContact(){
  fetch("https://modelin.webexam-mcdm.dk/api/contacts", {
    method: "post",
    headers: {
      "Content-Type" : "application/json"
    },
    body: JSON.stringify({
      email: document.getElementById("email").value,
      message: document.getElementById("message").value,
   })
  })
  .then((res) => {
    return res.json();
  })
  .then((resData) => {
    console.log(resData);
  })
}